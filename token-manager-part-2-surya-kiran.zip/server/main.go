package main

import (
	"context"
	"crypto/sha256"
	"encoding/binary"
	"flag"
	"fmt"
	"gopkg.in/yaml.v3"
	"io/ioutil"
	"log"
	"net"
	"os"
	"time"

	pb "example.com/suryakiran/token-manager/tokenmanager"
	"google.golang.org/grpc"
)

var (
	port = flag.Int("port", 50051, "The server port")
)

type Replication struct {
	Token   string
	Writer  string
	Readers []string
}

type server struct {
	pb.UnimplementedTokenManagerServer

	Tokens map[string]*pb.Token
}

func (s *server) CreateToken(ctx context.Context, id *pb.TokenId) (*pb.TokenResponse, error) {
	s.upsertToken(id.GetId(), &pb.Token{Id: id.GetId(), State: nil})
	return &pb.TokenResponse{Message: "Token with ID " + id.GetId() + " Saved", Success: true}, nil
}

func (s *server) ReplicateToken(ctx context.Context, token *pb.Token) (*pb.TokenResponse, error) {
	s.upsertToken(token.GetId(), token)
	return &pb.TokenResponse{Message: "Token with ID " + token.GetId() + " Replicated", Success: true}, nil
}

func (s *server) WriteToken(ctx context.Context, request *pb.TokenRequest) (*pb.TokenResponse, error) {
	token, ok := s.Tokens[request.GetId()]
	if ok {
		token = &pb.Token{Id: token.GetId(),
			Name:    token.GetName(),
			State:   &pb.State{PartialValue: ArgMin(request.Low, request.Mid, request.GetName())},
			Domain:  token.GetDomain(),
			Writer:  token.Writer,
			Readers: token.Readers,
		}
	} else {
		token = &pb.Token{Id: request.GetId(),
			Name:   request.GetName(),
			State:  &pb.State{PartialValue: ArgMin(request.Low, request.Mid, request.GetName())},
			Domain: &pb.Domain{Low: request.Low, Mid: request.Mid, High: request.High},
		}
	}
	s.upsertToken(request.GetId(), token)
	handleReplication(token)
	return &pb.TokenResponse{Message: "Token with ID " + request.GetId() + " Saved", Success: true}, nil
}

func handleReplication(token *pb.Token) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	for _, addr := range token.Readers {
		c, err := grpc.Dial(addr, grpc.WithInsecure())
		if err != nil {
			log.Fatalf("Unable to connect to server at %v, error %v", addr, err)
		}
		cli := pb.NewTokenManagerClient(c)
		cli.ReplicateToken(ctx, token)
	}
}

func (s *server) DeleteToken(ctx context.Context, id *pb.TokenId) (*pb.TokenResponse, error) {
	if _, ok := s.Tokens[id.GetId()]; ok {
		delete(s.Tokens, id.GetId())
		return &pb.TokenResponse{Message: "Token with ID " + id.GetId() + " Deleted", Success: true}, nil
	} else {
		return &pb.TokenResponse{Message: "Token with ID " + id.GetId() + " doesn't exist", Success: false}, nil
	}
}

func (s *server) ReadToken(ctx context.Context, id *pb.TokenId) (*pb.TokenResponse, error) {
	token, ok := s.Tokens[id.GetId()]
	if ok {
		argMinForFinalValue := ArgMin(token.GetDomain().GetMid(), token.GetDomain().GetHigh(), token.GetName())
		finalVal := min(argMinForFinalValue, token.GetState().GetPartialValue())
		updatedToken := &pb.Token{Id: token.GetId(),
			Name:    token.GetName(),
			State:   &pb.State{PartialValue: token.GetState().GetPartialValue(), FinalValue: finalVal},
			Domain:  token.GetDomain(),
			Writer:  token.Writer,
			Readers: token.Readers,
		}
		s.upsertToken(id.GetId(), updatedToken)
		return &pb.TokenResponse{Success: true, State: updatedToken.State}, nil
	} else {
		return &pb.TokenResponse{Message: "Token with ID " + id.GetId() + " doesn't exist", Success: false}, nil
	}
}

func (s *server) upsertToken(id string, token *pb.Token) {
	if s.Tokens == nil {
		s.Tokens = make(map[string]*pb.Token)
	}
	s.Tokens[id] = token
	log.Printf("upserted token %v", token)
}

func Hash(name string, nonce uint64) uint64 {
	hasher := sha256.New()
	hasher.Write([]byte(fmt.Sprintf("%s %d", name, nonce)))
	return binary.BigEndian.Uint64(hasher.Sum(nil))
}

func ArgMin(begin, end uint64, name string) uint64 {
	lowest := Hash(name, begin)
	argmin := begin
	for begin < end {
		h := Hash(name, begin)
		if h < lowest {
			lowest = h
			argmin = begin
		}
		begin += 1
	}
	return argmin
}

func min(val1, val2 uint64) uint64 {
	if val1 < val2 {
		return val1
	} else {
		return val2
	}
}

func main() {
	pwd, _ := os.Getwd()
	file, err := ioutil.ReadFile(pwd + "/replication.yaml")
	if err != nil {
		log.Fatalf("Unable to read replication yaml - %v", err)
	}

	var replicationData []Replication
	err2 := yaml.Unmarshal(file, &replicationData)
	if err2 != nil {
		log.Fatalf("Unable to Unmarshal replication yaml")
	}

	seedTokens := make(map[string]*pb.Token)
	for _, data := range replicationData {
		seedTokens[data.Token] = &pb.Token{Id: data.Token, State: nil, Writer: data.Writer, Readers: data.Readers}
	}

	flag.Parse()
	lis, err := net.Listen("tcp", fmt.Sprintf("localhost:%d", *port))
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}
	s := grpc.NewServer()
	pb.RegisterTokenManagerServer(s, &server{Tokens: seedTokens})
	log.Printf("Seed Data - Creating tokens from yml")
	log.Printf("server listening at %v", lis.Addr())
	if err := s.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}
