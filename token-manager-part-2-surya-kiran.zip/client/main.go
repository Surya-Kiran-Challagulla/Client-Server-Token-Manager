package main

import (
	"context"
	"encoding/json"
	pb "example.com/suryakiran/token-manager/tokenmanager"
	"flag"
	"fmt"
	"google.golang.org/grpc"
	"log"
	"os"
	"strconv"
	"time"
)

var (
	createCmd  = flag.NewFlagSet("create", flag.ExitOnError)
	createHost = createCmd.String("host", "localhost", "host to connect to")
	createPort = createCmd.String("port", "50051", "the port to connect to")
	createId   = createCmd.String("id", "", "the id of token")

	writeCmd  = flag.NewFlagSet("write", flag.ExitOnError)
	writeHost = writeCmd.String("host", "localhost", "host to connect to")
	writePort = writeCmd.String("port", "50051", "the port to connect to")
	writeId   = writeCmd.String("id", "", "the id of token")
	writeName = writeCmd.String("name", "", "the name of token")
	low       = writeCmd.String("low", "", "the low of token")
	mid       = writeCmd.String("mid", "", "the mid of token")
	high      = writeCmd.String("high", "", "the high of token")

	readCmd  = flag.NewFlagSet("read", flag.ExitOnError)
	readHost = readCmd.String("host", "localhost", "host to connect to")
	readPort = readCmd.String("port", "50051", "the port to connect to")
	readId   = readCmd.String("id", "", "the id of token")

	dropCmd  = flag.NewFlagSet("drop", flag.ExitOnError)
	dropHost = dropCmd.String("host", "localhost", "host to connect to")
	dropPort = dropCmd.String("port", "50051", "the port to connect to")
	dropId   = dropCmd.String("id", "", "the id of token")
)

func main() {
	if len(os.Args) < 2 {
		log.Printf("expected 'create', 'write', 'read' or 'drop' subcommands")
		os.Exit(1)
	}

	var conn *grpc.ClientConn
	var client pb.TokenManagerClient

	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	switch os.Args[1] {
	case "create":
		createCmd.Parse(os.Args[2:])
		conn, client = makeClient(*createHost, *createPort)
		r, err := client.CreateToken(ctx, &pb.TokenId{Id: *createId})
		showResult(r, err)
	case "write":
		writeCmd.Parse(os.Args[2:])

		l, _ := strconv.ParseUint(*low, 10, 64)
		m, _ := strconv.ParseUint(*mid, 10, 64)
		h, _ := strconv.ParseUint(*high, 10, 64)
		request := &pb.TokenRequest{Id: *writeId, Name: *writeName, Low: l, Mid: m, High: h}

		conn, client = makeClient(*writeHost, *writePort)
		r, err := client.WriteToken(ctx, request)
		showResult(r, err)
	case "read":
		readCmd.Parse(os.Args[2:])
		conn, client = makeClient(*readHost, *readPort)
		r, err := client.ReadToken(ctx, &pb.TokenId{Id: *readId})
		showResult(r, err)
	case "drop":
		dropCmd.Parse(os.Args[2:])
		conn, client = makeClient(*dropHost, *dropPort)
		r, err := client.DeleteToken(ctx, &pb.TokenId{Id: *dropId})
		showResult(r, err)
	default:
		fmt.Println("expected 'create', 'write', 'read' or 'drop' subcommands")
		os.Exit(1)
	}
	conn.Close()
}

func connection(host string, port string) *grpc.ClientConn {
	addr := host + ":" + port
	c, err := grpc.Dial(addr, grpc.WithInsecure())
	if err != nil {
		log.Fatalf("Unable to connect to server at %v, error %v", addr, err)
	}
	return c
}

func makeClient(host string, port string) (*grpc.ClientConn, pb.TokenManagerClient) {
	conn := connection(*dropHost, *dropPort)
	cli := pb.NewTokenManagerClient(conn)
	return conn, cli
}

func showResult(r *pb.TokenResponse, err error) {
	if err != nil {
		log.Fatalf("something went wrong, error: %v", err)
	}
	indented, _ := json.MarshalIndent(r, "", "  ")
	fmt.Printf("%v \n", string(indented))
}
