## About The Project
This is a token generator project built using Go and gRPCs with Protocol Buffers.
### Built With
* [Protocol Buffer](https://developers.google.com/protocol-buffers/docs/gotutorial)
* [Go](https://go.dev/)
* [Proto3](https://developers.google.com/protocol-buffers/docs/proto3)
## Getting Started
### Prerequisites
* Go is installed
* Protocol buffer compiler, protoc, version 3 is installed https://developers.google.com/protocol-buffers
## Usage
Once you untar the file, there will be three directories and two executables
#### Directories
1. client - this contains code for client code
2. server - this contains code for server code
3. tokenmanager - this contains proto file and auto generated buffers and rpc interfaces. Please see below of command used to generate these files. Here is the command `protoc --go_out=. --go_opt=paths=source_relative --go-grpc_out=. --go-grpc_opt=paths=source_relative tokenmanager/tokenmanager.proto`
#### Executables
1. tokenclient - this executable binary for client
2. tokenserver - this executable binary for server
### Start the server 

```go
./tokenserver 
```
By default, it runs on port `50051`, however this can be overridden using `-port` flag, like so 
```
./tokenserver -port=50056
```

### Create Token
Once the server is running client can be invoked using following command to create a token 

```go
./tokenclient create -id=token-number-10 
```
Sample output
```json
{
  "success": true,
  "message": "Token with ID token-10 Saved"
}
```
By default, it runs on host `localhost` and port `50051`, however this can be overridden using `-host` and `-port` flags, like so
```
./tokenclient create -id=token-1 -host=localhost -port=50051
```

### Write Token
Once the server is running client can be invoked using following command to write a token

```go
./tokenclient write -id=token-8 -name=dinesh -low=1 -mid=50 -high=75 -host=localhost -port=50051
```
Sample output
```json
{
  "success": true,
  "message": "Token with ID token-8 Saved"
} 
```

### Read Token
Once the server is running client can be invoked using following command to read a token

```go
./tokenclient read -id=token-8 -host=localhost -port=50051
```
Sample output. `data` represents the expected the output of the operation
```json
{
  "success": true,
  "data": 20
}  
```

### Drop Token
Once the server is running client can be invoked using following command to drop a token

```go
./tokenclient drop -id=token-8
```
Sample output. 
```json
{
  "success": true,
  "message": "Token with ID token-8 Deleted"
}
```
## Replication
Replication is handled via configuration specified in yaml file. To test replication, update `Readers` and `Writer` section in the file `replication.yaml`. Currently file has three nodes (servers) `127.0.0.1:50051`, `127.0.0.1:50052`, `127.0.0.1:50053` acting as `Writer` and/or `Readers` for `token-1` and `token-2`

### Start server nodes 
To begin with Spin up server nodes. For current yaml configuration, we will need to run these servers `127.0.0.1:50051`, `127.0.0.1:50052`, `127.0.0.1:50053`

```shell
./tokenserver -port=50051
./tokenserver -port=50052
./tokenserver -port=50053
```

**Make sure that all three servers are started, and a log message is displayed indicating all servers created seed data of predefined tokens in yaml.**

Above step can be verified by executing the read command to all servers.

```shell
 ./tokenclient read -id=token-1 -host=localhost -port=50053                             
```

Response
```json
{
  "success": true,
  "state": {}
}
```

### Testing Replication
To test the replication, issue a `write` command on `Writer` node for a given token.

```shell
./tokenclient write -id=token-1 -name=first-token -low=350 -mid=500 -high=750 -host=localhost -port=50051
```
Replication can be observed via server logs for `127.0.0.1:50052`, `127.0.0.1:50053`

Alternatively, read command can be used on 127.0.0.1:50052 or 127.0.0.1:50053, notice the state value being replicated to other servers.

```shell
./tokenclient read -id=token-1 -host=localhost -port=50053
```

Response
```json
{
  "success": true,
  "state": {
    "partial_value": 412
  }
}
```

```shell
./tokenclient read -id=token-1 -host=localhost -port=50052
```

Response
```json
{
  "success": true,
  "state": {
    "partial_value": 412
  }
}
```